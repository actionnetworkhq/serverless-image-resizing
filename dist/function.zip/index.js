'use strict';

const resize = require('./lib/functions/resize');
const compress = require('./lib/functions/compress');

module.exports = {
    resize,
    compress,
};
