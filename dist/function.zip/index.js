'use strict';

const trythis = require('@fizzygalacticus/trythis');

const resize = require('./lib/functions/resize');
const compress = require('./lib/functions/compress');

module.exports = {
    resize: trythis(resize),
    compress,
};
